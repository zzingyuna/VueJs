import { add, var1  } from './utils/utility2';

console.log(add(4,5));
console.log(var1);
