let var1 = 1000;
function add(a,b) {
    return a+b;
}

export { var1, add };