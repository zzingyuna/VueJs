let calc = {
    add(x,y) {
        return x+y;
    },
    multiply(x,y) {
        return x*y;
    }
}

export default calc;