export default {
    SEARCH_CONTACT : "searchContact",
    BASE_URL : "http://sample.bmaster.kro.kr/contacts/search/"
}
