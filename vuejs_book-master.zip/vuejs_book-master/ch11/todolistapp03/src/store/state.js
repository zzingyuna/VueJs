import Constant from '../constant';

export default {
    todolist : [
        { todo : "영화보기", done:false },
        { todo : "주말 산책", done:true },
        { todo : "ES6 학습", done:false },
        { todo : "잠실 야구장", done:false }
    ]
}