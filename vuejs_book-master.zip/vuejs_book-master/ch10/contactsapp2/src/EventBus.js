import Vue from 'vue';

var EventBus = new Vue();
export default EventBus;


