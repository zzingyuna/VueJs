<template>
    <contactForm mode="add" />
</template>

<script>
import ContactForm from './ContactForm.vue';

export default {
    name : "addContact",
    components : { ContactForm }
}
</script>

<style scoped>
</style>