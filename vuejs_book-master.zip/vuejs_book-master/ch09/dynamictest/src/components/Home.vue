<template>
  <div>
      <h1>Home</h1>
      <h3>{{ (new Date()).toTimeString() }}</h3>
  </div>
</template>
<script>
export default {
  name : "home"
}
</script>
