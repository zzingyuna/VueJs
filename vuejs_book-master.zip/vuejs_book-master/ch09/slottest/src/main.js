import Vue from 'vue'
//import App from './App.vue'
//import App from './AppNamed.vue'
import App from './AppScoped.vue'

new Vue({
  el: '#app',
  render: h => h(App)
})
