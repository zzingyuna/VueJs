각 절별 예제
- 9.1 : todolistapp
- 9.2.1 : styletest1
- 9.2.2 : styletest2
- 9.3 : slottest 
- 9.4~5 : dynamictest